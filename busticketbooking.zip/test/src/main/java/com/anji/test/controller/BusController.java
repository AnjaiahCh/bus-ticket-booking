package com.anji.test.controller;

/example/busticketbooking/controller/BusController.java
package com.example.busticketbooking.controller;

import com.example.busticketbooking.model.Bus;
import com.example.busticketbooking.service.BusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class BusController {
    @Autowired
    private BusService busService;

    @GetMapping("/buses")
    public String listBuses(Model model) {
        model.addAttribute("buses", busService.findAll());
        return "buses";
    }

    @GetMapping("/add-bus")
    public String showAddBusForm(Model model) {
        model.addAttribute("bus", new Bus());
        return "add-bus";
    }

    @PostMapping("/add-bus")
    public String addBus(Bus bus) {
        busService.save(bus);
        return "redirect:/buses";
    }
}