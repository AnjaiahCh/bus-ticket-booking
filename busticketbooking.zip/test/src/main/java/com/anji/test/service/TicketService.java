package com.anji.test.service;


import com.example.busticketbooking.model.Ticket;
import com.example.busticketbooking.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketService {
    @Autowired
    private TicketRepository ticketRepository;

    public Ticket save(Ticket ticket) {
        return ticketRepository.save(ticket);
    }

    public List<Ticket> findByUserId(Long userId) {
        return ticketRepository.findByUserId(userId);
    }

    public List<Ticket> findByBusId(Long busId) {
        return ticketRepository.findByBusId(busId);
    }
}