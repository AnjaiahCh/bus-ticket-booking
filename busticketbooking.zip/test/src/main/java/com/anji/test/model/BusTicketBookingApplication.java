package com.anji.test.model;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusTicketBookingApplication {
    public static void main(String[] args) {
        SpringApplication.run(BusTicketBookingApplication.class, args);
    }
}


