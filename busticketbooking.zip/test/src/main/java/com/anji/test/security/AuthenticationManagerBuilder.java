package com.anji.test.security;

public interface AuthenticationManagerBuilder {

}
