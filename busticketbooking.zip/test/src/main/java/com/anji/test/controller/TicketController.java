package com.anji.test.controller;


import com.example.busticketbooking.model.Ticket;
import com.example.busticketbooking.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TicketController {
    @Autowired
    private TicketService ticketService;

    @GetMapping("/tickets")
    public String listTickets(Model model) {
        model.addAttribute("tickets", ticketService.findByUserId(1L)); // Assuming a logged-in user with ID 1
        return "tickets";
    }

    @GetMapping("/book-ticket")
    public String showBookingForm(Model model) {
        model.addAttribute("ticket", new Ticket());
        return "book-ticket";
    }

    @PostMapping("/book-ticket")
    public String bookTicket(Ticket ticket) {
        ticketService.save(ticket);
        return "redirect:/tickets";
    }
}