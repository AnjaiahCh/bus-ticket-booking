package com.anji.test.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Bus {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
private String busNumber;
private String route;
private String departureTime;
private int availableSeats;
// getters and setters
}