package org.springframework.security.config.annotation.authentication.builders;

public interface AuthenticationManagerBuilder {

}
