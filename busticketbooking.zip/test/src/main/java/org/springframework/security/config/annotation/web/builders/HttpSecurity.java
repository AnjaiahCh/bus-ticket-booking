package org.springframework.security.config.annotation.web.builders;

public interface HttpSecurity {

}
